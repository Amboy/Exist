require 'test_helper'

class ArticlesHelperTest < ActionView::TestCase
end
