require 'test_helper'

class AuthorsHelperTest < ActionView::TestCase
end
