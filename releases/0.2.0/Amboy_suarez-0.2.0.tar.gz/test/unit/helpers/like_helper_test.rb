require 'test_helper'

class LikeHelperTest < ActionView::TestCase
end
