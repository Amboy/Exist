class AuthorSession < Authlogic::Session::Base
end